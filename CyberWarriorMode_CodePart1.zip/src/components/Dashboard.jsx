import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import missions from "../data/missions.json";
import XPTracker from "./XPTracker";
import BadgeDisplay from "./BadgeDisplay";
import ReminderModal from "./ReminderModal";

const Dashboard = () => {
  const navigate = useNavigate();
  const [completed, setCompleted] = useState(0);
  const [theme, setTheme] = useState("redteam");

  useEffect(() => {
    const stored = localStorage.getItem("completedMissions");
    if (stored) setCompleted(parseInt(stored));
  }, []);

  useEffect(() => {
    document.body.style.backgroundColor = theme === "redteam" ? "#1a000f" : "#001a1f";
  }, [theme]);

  const handleClick = (index) => {
    if (index <= completed) {
      navigate(`/mission/${index + 1}`);
    }
  };

  const resetProgress = () => {
    localStorage.setItem("completedMissions", "0");
    window.location.reload();
  };

  return (
    <div className="min-h-screen text-white font-techno p-6">
      <h1 className="text-2xl mb-4">CyberWarrior Dashboard</h1>

      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => setTheme(theme === "redteam" ? "blueteam" : "redteam")}
          className="px-4 py-2 border rounded"
        >
          Switch to {theme === "redteam" ? "BlueTeam" : "RedTeam"} Mode
        </button>
        <button onClick={resetProgress} className="px-4 py-2 bg-red-700 rounded">
          Reset Progress
        </button>
      </div>

      <XPTracker completed={completed} />
      <BadgeDisplay completed={completed} />

      <div className="grid grid-cols-2 gap-4 mt-6">
        {missions.map((m, index) => (
          <button
            key={index}
            disabled={index > completed}
            onClick={() => handleClick(index)}
            className={`p-4 rounded border ${
              index <= completed
                ? "border-cyber-neon hover:bg-cyber-blue"
                : "border-gray-700 text-gray-500"
            }`}
          >
            {`Day ${index + 1}: ${m.title}`}
          </button>
        ))}
      </div>
      <ReminderModal />
    </div>
  );
};

export default Dashboard;