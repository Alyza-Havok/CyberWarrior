const XPTracker = ({ completed }) => {
  const xp = completed * 15;
  const level = Math.floor(xp / 50);
  const percent = Math.min((completed / 21) * 100, 100);

  return (
    <div className="w-full mb-2">
      <div className="text-white text-sm mb-1">
        XP: {xp} | Level: {level} | Progress: {percent.toFixed(0)}%
      </div>
      <div className="w-full h-3 bg-gray-800 rounded">
        <div
          className="h-full bg-cyber-neon rounded transition-all"
          style={{ width: `${percent}%` }}
        ></div>
      </div>
    </div>
  );
};

export default XPTracker;